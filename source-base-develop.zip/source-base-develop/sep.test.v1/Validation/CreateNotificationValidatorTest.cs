﻿using FluentValidation.TestHelper;
using Microsoft.EntityFrameworkCore;
using sep.backend.v1.Common.Const;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.Extensions.EF;
using sep.backend.v1.Helpers;
using sep.backend.v1.Validators;
using Xunit;
using sep.backend.v1.DTOs;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Collections.Generic;

namespace sep.test.v1.Validators
{
    public class CreateNotificationValidatorTest
    {
        private readonly NotificationValidator _validator;
        private readonly ApplicationContext _context;

        public CreateNotificationValidatorTest()
        {
            var options = new DbContextOptionsBuilder<ApplicationContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationContext(options);

            // Seed test data
            _context.NotificationCategories.Add(new NotificationCategory { Id = 1, Name = "Category 1" });
            _context.NotificationCategories.Add(new NotificationCategory { Id = 2, Name = "Category 2" });
            _context.SaveChanges();

            _validator = new NotificationValidator(_context);
        }

        [Fact]
        public void Should_Have_Error_When_Title_Is_Empty()
        {
            var model = new AddNotificationDTO { Title = "" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Title).WithErrorMessage(StringHelper.FormatMessage(Messages.REQUIRED, "Tiêu đề"));
        }

        [Fact]
        public void Should_Have_Error_When_Title_Exceeds_MaxLength()
        {
            var model = new AddNotificationDTO { Title = new string('a', 101) };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Title).WithErrorMessage(StringHelper.FormatMaxLengthMessage(Messages.MAX, "Tiêu đề", 100));
        }

        [Fact]
        public void Should_Have_Error_When_Descriptions_Is_Empty()
        {
            var model = new AddNotificationDTO { Descriptions = "" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Descriptions).WithErrorMessage(StringHelper.FormatMessage(Messages.REQUIRED, "Mô tả"));
        }

        [Fact]
        public void Should_Have_Error_When_Descriptions_Exceeds_MaxLength()
        {
            var model = new AddNotificationDTO { Descriptions = new string('a', 501) };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Descriptions).WithErrorMessage(StringHelper.FormatMaxLengthMessage(Messages.MAX, "Mô tả", 500));
        }

        [Fact]
        public void Should_Have_Error_When_CategoryId_Is_Empty()
        {
            var model = new AddNotificationDTO { CategoryId = null };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.CategoryId).WithErrorMessage(StringHelper.FormatMessage(Messages.REQUIRED, "Thể loại"));
        }

        [Fact]
        public void Should_Have_Error_When_CategoryId_Is_Invalid()
        {
            var model = new AddNotificationDTO { CategoryId = 999 }; // Invalid ID
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.CategoryId).WithErrorMessage("Thể loại không hợp lệ.");
        }

        [Fact]
        public void Should_Not_Have_Error_When_Model_Is_Valid()
        {
            var model = new AddNotificationDTO
            {
                Title = "Valid Title",
                Descriptions = "Valid Description",
                CategoryId = 1
            };
            var result = _validator.TestValidate(model);
            result.ShouldNotHaveAnyValidationErrors();
        }

        [Fact]
        public void Should_Have_Error_When_FileImage_Is_Invalid_Type()
        {
            var model = new AddNotificationDTO
            {
                FileImage = new List<IFormFile>
                {
                    new FormFile(new MemoryStream(new byte[1]), 0, 1, "test", "test.txt")
                }
            };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor("FileImage[0].FileName").WithErrorMessage("Không đúng định dạng. Các file hợp lệ PNG, JPG, JPEG, and GIF.");
        }

        [Fact]
        public void Should_Have_Error_When_FileImage_Exceeds_Max_Size()
        {
            var model = new AddNotificationDTO
            {
                FileImage = new List<IFormFile>
                {
                    new FormFile(new MemoryStream(new byte[5 * 1024 * 1024 + 1]), 0, 5 * 1024 * 1024 + 1, "test", "test.jpg")
                }
            };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor("FileImage[0].Length").WithErrorMessage("File vượt quá dung lượng 5MB.");
        }

    }
}
