﻿using FluentValidation.TestHelper;
using Microsoft.EntityFrameworkCore;
using sep.backend.v1.Common.Const;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.DTOs;
using sep.backend.v1.Helpers;
using sep.backend.v1.Validators.SchoolAdmin;
using Xunit;
using System;
using sep.backend.v1.Extensions.EF;

namespace sep.test.v1.Validators
{
    public class CreateAndUpdateSemesterValidatorTest
    {
        private readonly SemesterValidator _validator;
        private readonly ApplicationContext _context;

        public CreateAndUpdateSemesterValidatorTest()
        {
            var options = new DbContextOptionsBuilder<ApplicationContext>()
        .UseInMemoryDatabase(Guid.NewGuid().ToString())
        .Options;

            _context = new ApplicationContext(options);

            // Seed test data
            _context.SchoolYears.Add(new SchoolYear { Id = 1, SchoolId = 1, Name = "2020-2021", StartDate = new DateTime(2020, 9, 1), EndDate = new DateTime(2021, 6, 30) });
            _context.Semesters.Add(new Semester { Id = 1, SchoolYearId = 1, SemesterCode = "FALL2020", SemesterName = "Fall 2020", StartDate = new DateTime(2020, 9, 1), EndDate = new DateTime(2020, 12, 31) });
            _context.SaveChanges();

            _validator = new SemesterValidator(_context);
        }

        [Fact]
        public void Should_Have_Error_When_SemesterName_Is_Empty()
        {
            var model = new CreateAndUpdateSemesterDTO { SemesterName = string.Empty };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.SemesterName).WithErrorMessage(StringHelper.FormatMessage(Messages.REQUIRED, "Tên kì học"));
        }

        [Fact]
        public void Should_Have_Error_When_SemesterCode_Is_Empty()
        {
            var model = new CreateAndUpdateSemesterDTO { SemesterCode = string.Empty };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.SemesterCode).WithErrorMessage(StringHelper.FormatMessage(Messages.REQUIRED, "Code kì học"));
        }

        [Fact]
        public void Should_Have_Error_When_StartDate_Is_Empty()
        {
            var model = new CreateAndUpdateSemesterDTO { StartDate = null };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.StartDate).WithErrorMessage(StringHelper.FormatMessage(Messages.REQUIRED, "Ngày bắt đầu"));
        }

        [Fact]
        public void Should_Have_Error_When_EndDate_Is_Empty()
        {
            var model = new CreateAndUpdateSemesterDTO { EndDate = null };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.EndDate).WithErrorMessage(StringHelper.FormatMessage(Messages.REQUIRED, "Ngày kết thúc"));
        }

        [Fact]
        public void Should_Have_Error_When_EndDate_Is_Before_Today()
        {
            var model = new CreateAndUpdateSemesterDTO { StartDate = DateTime.Today.AddDays(-1), EndDate = DateTime.Today.AddDays(-1) };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.EndDate).WithErrorMessage("Ngày kết thúc phải sau ngày hôm nay");
        }

        [Fact]
        public void Should_Have_Error_When_EndDate_Is_Before_StartDate_By_Less_Than_30_Days()
        {
            var model = new CreateAndUpdateSemesterDTO { StartDate = DateTime.Today, EndDate = DateTime.Today.AddDays(29) };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.EndDate).WithErrorMessage("Ngày kết thúc phải sau ngày bắt đầu ít nhất 30 ngày.");
        }

    }
}
