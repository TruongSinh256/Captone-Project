﻿using FluentValidation.TestHelper;
using Microsoft.EntityFrameworkCore;
using sep.backend.v1.Common.Const;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.DTOs;
using sep.backend.v1.Extensions.EF;
using sep.backend.v1.Helpers;
using sep.backend.v1.Validators;
using Xunit;
using System;
using System.Linq;

namespace sep.test.v1.Validators
{
    public class PupilScoreValidatorTest
    {
        private readonly PupilScoreValidator _validator;
        private readonly ApplicationContext _context;

        public PupilScoreValidatorTest()
        {
            var options = new DbContextOptionsBuilder<ApplicationContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationContext(options);

            // Seed test data
            _context.Subjects.Add(new Subject { Id = 1, Name = "Math", Code = "MATH101" });
            _context.Pupils.Add(new Pupil
            {
                Id = 1,
                FirstName = "John",
                LastName = "Doe",
                Username = "johndoe",
                Password = "password123",
                ShortRoleName = "Student"
            });
            _context.Semesters.Add(new Semester { Id = 1, SemesterName = "2023 Semester 1", SemesterCode = "SEM20231" });
            _context.PupilScores.Add(new PupilScore
            {
                PupilId = 1,
                SubjectId = 1,
                SemesterId = 1,
                Score = 8,
                CreatedDate = DateTime.Now
            });

            _context.SaveChanges();

            _validator = new PupilScoreValidator(_context);
        }

        [Fact]
        public void Should_Have_Error_When_SubjectId_Is_Invalid()
        {
            var model = new PupilScoreDTO { SubjectId = 999, PupilId = 1, SemesterId = 1, Score = 8 };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.SubjectId).WithErrorMessage(StringHelper.FormatMessage(Messages.NOT_EXIST, "Môn học"));
        }

        [Fact]
        public void Should_Have_Error_When_PupilId_Is_Invalid()
        {
            var model = new PupilScoreDTO { SubjectId = 1, PupilId = 999, SemesterId = 1, Score = 8 };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.PupilId).WithErrorMessage(StringHelper.FormatMessage(Messages.NOT_EXIST, "Học sinh"));
        }

        [Fact]
        public void Should_Have_Error_When_SemesterId_Is_Invalid()
        {
            var model = new PupilScoreDTO { SubjectId = 1, PupilId = 1, SemesterId = 999, Score = 8 };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.SemesterId).WithErrorMessage(StringHelper.FormatMessage(Messages.NOT_EXIST, "Học kỳ"));
        }

        [Fact]
        public void Should_Have_Error_When_Score_Is_Out_Of_Range()
        {
            var model = new PupilScoreDTO { SubjectId = 1, PupilId = 1, SemesterId = 1, Score = 11 };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Score).WithErrorMessage(StringHelper.FormatMessage(Messages.INVALID, "Điểm số"));
        }

        [Fact]
        public void Should_Have_Error_When_Status_Is_Invalid()
        {
            var model = new PupilScoreDTO { SubjectId = 1, PupilId = 1, SemesterId = 1, Score = 8, Status = 999 };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Status).WithErrorMessage(StringHelper.FormatMessage(Messages.INVALID, "Trạng thái điểm số"));
        }

        [Fact]
        public void Should_Have_Error_When_Score_Already_Exists_For_Subject_And_Semester()
        {
            var model = new PupilScoreDTO { SubjectId = 1, PupilId = 1, SemesterId = 1, Score = 8, CreatedDate = null };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Score).WithErrorMessage(StringHelper.FormatMessage(Messages.IS_EXIST, "Điểm số cho môn học và học kỳ này"));
        }

    }
}