﻿using Microsoft.EntityFrameworkCore;
using sep.backend.v1.Data.Entities;
using Xunit;
using FluentValidation.TestHelper;
using sep.backend.v1.Extensions.EF;
using sep.backend.v1.Validators;
using sep.backend.v1.Common.Const;

namespace sep.test.v1.Validators
{
    public class RegisterSchoolValidatorTest
    {
        private readonly RegisterSchoolValidator _validator;
        private readonly ApplicationContext _context;

        public RegisterSchoolValidatorTest()
        {
            var options = new DbContextOptionsBuilder<ApplicationContext>()
                .UseInMemoryDatabase("TestDatabase")
                .Options;

            _context = new ApplicationContext(options);

            _context.Schools.Add(new School
            {
                Username = "existingUsername",
                Email = "existing@example.com",
                Name = "Existing School",
                Password = "password123",
                ShortRoleName = "SA"
            });
            _context.SaveChanges();

            _validator = new RegisterSchoolValidator(_context);
        }

        [Fact]
        public void Should_Have_Error_When_Username_Is_Not_Unique()
        {
            var model = new RegisterDTORemake { Username = "existingUsername" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Username).WithErrorMessage(Messages.USERNAME_EXISTS);
        }

        [Fact]
        public void Should_Have_Error_When_Email_Is_Not_Unique()
        {
            var model = new RegisterDTORemake { Email = "existing@example.com" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Email).WithErrorMessage(Messages.EMAIL_EXISTS);
        }

        [Fact]
        public void Should_Have_Error_When_Username_Is_Empty()
        {
            var model = new RegisterDTORemake { Username = "" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Username).WithErrorMessage(Messages.USERNAME_REQUIRED);
        }

        [Fact]
        public void Should_Have_Error_When_Username_Length_Is_Invalid()
        {
            var model = new RegisterDTORemake { Username = "a" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Username).WithErrorMessage(Messages.USERNAME_LENGTH);
        }

        [Fact]
        public void Should_Have_Error_When_Username_Has_Invalid_Characters()
        {
            var model = new RegisterDTORemake { Username = "user@name" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Username).WithErrorMessage(Messages.USERNAME_LETTER);
        }

        [Fact]
        public void Should_Have_Error_When_Name_Is_Empty()
        {
            var model = new RegisterDTORemake { Name = "" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Name).WithErrorMessage(Messages.NAME_REQUIRED);
        }

        [Fact]
        public void Should_Have_Error_When_Name_Length_Is_Invalid()
        {
            var model = new RegisterDTORemake { Name = "a" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Name).WithErrorMessage(Messages.NAME_LENGTH);
        }

        [Fact]
        public void Should_Have_Error_When_Email_Is_Empty()
        {
            var model = new RegisterDTORemake { Email = "" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Email).WithErrorMessage(Messages.EMAIL_REQUIRED);
        }

        [Fact]
        public void Should_Have_Error_When_Email_Is_Invalid()
        {
            var model = new RegisterDTORemake { Email = "invalid-email" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Email).WithErrorMessage(Messages.EMAIL_INVALID);
        }

        [Fact]
        public void Should_Have_Error_When_Password_Is_Empty()
        {
            var model = new RegisterDTORemake { Password = "" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Password).WithErrorMessage(Messages.PASSWORD_REQUIRED);
        }

        [Fact]
        public void Should_Have_Error_When_Password_Length_Is_Invalid()
        {
            var model = new RegisterDTORemake { Password = "123" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Password).WithErrorMessage(Messages.PASSWORD_LENGTH);
        }

        [Fact]
        public void Should_Have_Error_When_RePassword_Does_Not_Match()
        {
            var model = new RegisterDTORemake { Password = "password123", RePassword = "password456" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.RePassword).WithErrorMessage(Messages.PASSWORD_MATCH);
        }
    }
}