﻿using FluentValidation.TestHelper;
using Microsoft.EntityFrameworkCore;
using sep.backend.v1.Common.Const;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.DTOs;
using sep.backend.v1.Helpers;
using sep.backend.v1.Validators.SchoolAdmin;
using Xunit;
using System;
using sep.backend.v1.Extensions.EF;

namespace sep.test.v1.Validators
{
    public class SubjectValidatorTest
    {
        private readonly SubjectValidator _validator;
        private readonly ApplicationContext _context;

        public SubjectValidatorTest()
        {
            var options = new DbContextOptionsBuilder<ApplicationContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationContext(options);

            // Seed test data
            _context.Subjects.Add(new Subject { Id = 1, Name = "Mathematics", Code = "MATH", SchoolId = 1 });
            _context.SaveChanges();

            _validator = new SubjectValidator(_context);
        }

        [Fact]
        public void Should_Have_Error_When_Name_Is_Empty()
        {
            var model = new SubjectDTO { Name = "", Code = "SCI", SchoolId = 1 };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Name).WithErrorMessage(StringHelper.FormatMessage(Messages.REQUIRED, "Tên môn học"));
        }

        [Fact]
        public void Should_Have_Error_When_Name_Exceeds_MaxLength()
        {
            var model = new SubjectDTO { Name = new string('a', 51), Code = "SCI", SchoolId = 1 };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Name).WithErrorMessage(StringHelper.FormatMaxLengthMessage(Messages.MAX, "Tên môn học", 50));
        }

        [Fact]
        public void Should_Have_Error_When_Name_Is_Not_Unique()
        {
            var model = new SubjectDTO { Name = "Mathematics", Code = "SCI", SchoolId = 1 };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Name).WithErrorMessage(StringHelper.FormatMessage(Messages.UNIQUE, "Tên môn học"));
        }

        [Fact]
        public void Should_Have_Error_When_Code_Is_Empty()
        {
            var model = new SubjectDTO { Name = "Science", Code = "", SchoolId = 1 };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Code).WithErrorMessage(StringHelper.FormatMessage(Messages.REQUIRED, "Tên viết tắt"));
        }

        [Fact]
        public void Should_Have_Error_When_Code_Exceeds_MaxLength()
        {
            var model = new SubjectDTO { Name = "Science", Code = new string('a', 11), SchoolId = 1 };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Code).WithErrorMessage(StringHelper.FormatMaxLengthMessage(Messages.MAX, "Tên viết tắt", 10));
        }

        [Fact]
        public void Should_Not_Have_Error_When_Model_Is_Valid()
        {
            var model = new SubjectDTO { Name = "Physics", Code = "PHYS", SchoolId = 1 };
            var result = _validator.TestValidate(model);
            result.ShouldNotHaveAnyValidationErrors();
        }
    }
}
