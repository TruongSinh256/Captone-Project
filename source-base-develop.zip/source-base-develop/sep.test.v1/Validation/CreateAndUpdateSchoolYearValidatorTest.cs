﻿using FluentValidation.TestHelper;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Moq;
using sep.backend.v1.Common.Const;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.DTOs;
using sep.backend.v1.Extensions.EF;
using sep.backend.v1.Helpers;
using sep.backend.v1.Validators.SchoolAdmin;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace sep.test.v1.Validators
{
    public class CreateAndUpdateSchoolYearValidatorTest
    {
        private readonly SchoolYearValidator _validator;
        private readonly ApplicationContext _context;
        private readonly Mock<IHttpContextAccessor> _httpContextAccessorMock;

        public CreateAndUpdateSchoolYearValidatorTest()
        {
            var options = new DbContextOptionsBuilder<ApplicationContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationContext(options);

            // Seed test data
            _context.SchoolYears.Add(new SchoolYear { Id = 1, SchoolId = 1, Name = "2020-2021", StartDate = new DateTime(2020, 9, 1), EndDate = new DateTime(2021, 6, 30) });
            _context.Semesters.Add(new Semester { Id = 1, SchoolYearId = 1, SemesterCode = "FALL2020", SemesterName = "Fall 2020", StartDate = new DateTime(2020, 9, 1), EndDate = new DateTime(2020, 12, 31) });
            _context.SaveChanges();

            _httpContextAccessorMock = new Mock<IHttpContextAccessor>();
            var httpContext = new DefaultHttpContext();
            httpContext.Items["SchoolId"] = 1; // Add SchoolId to HttpContext.Items
            _httpContextAccessorMock.Setup(x => x.HttpContext).Returns(httpContext);

            _validator = new SchoolYearValidator(_context, _httpContextAccessorMock.Object);
        }

        [Fact]
        public void Should_Have_Error_When_EndDate_Is_Before_Today()
        {
            var model = new CreateAndUpdateSchoolYearDTO { EndDate = DateTime.Today.AddDays(-1) };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.EndDate).WithErrorMessage("Ngày kết thúc phải sau ngày hôm nay");
        }

        [Fact]
        public void Should_Have_Error_When_EndDate_Is_Less_Than_180_Days_After_StartDate()
        {
            var model = new CreateAndUpdateSchoolYearDTO
            {
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddDays(179)
            };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.EndDate).WithErrorMessage("Ngày kết thúc phải sau ngày bắt đầu tối thiểu 180 ngày.");
        }

    }
}
