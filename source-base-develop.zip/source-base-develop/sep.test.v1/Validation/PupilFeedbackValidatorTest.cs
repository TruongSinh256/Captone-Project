﻿using FluentValidation.TestHelper;
using Microsoft.EntityFrameworkCore;
using sep.backend.v1.Common.Const;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.DTOs;
using sep.backend.v1.Helpers;
using sep.backend.v1.Validators;
using Xunit;
using System;
using System.Linq;
using sep.backend.v1.Extensions.EF;

namespace sep.test.v1.Validators
{
    public class PupilFeedbackValidatorTest
    {
        private readonly PupilFeedbackValidator _validator;
        private readonly ApplicationContext _context;

        public PupilFeedbackValidatorTest()
        {
            var options = new DbContextOptionsBuilder<ApplicationContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationContext(options);

            // Seed test data
            _context.Pupils.Add(new Pupil
            {
                Id = 1,
                FirstName = "John",
                LastName = "Doe",
                Username = "johndoe",
                Password = "password123",
                ShortRoleName = "DN"
            });

            _context.Semesters.Add(new Semester
            {
                Id = 1,
                SemesterName = "2023 Semester 1",
                SemesterCode = "SEM20231", // Populate required property
                StartDate = DateTime.Now.AddMonths(-3),
                EndDate = DateTime.Now.AddMonths(3)
            });
            _context.PupilFeedbacks.Add(new PupilFeedback
            {
                PupilId = 1,
                SemesterId = 1,
                Description = "Duplicate feedback",
                CreatedDate = DateTime.Now
            });

            _context.SaveChanges();

            _validator = new PupilFeedbackValidator(_context);
        }

        [Fact]
        public void Should_Have_Error_When_PupilId_Does_Not_Exist()
        {
            var model = new PupilFeedbackDTO { PupilId = 999, SemesterId = 1, Description = "Feedback" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.PupilId).WithErrorMessage(StringHelper.FormatMessage(Messages.NOT_EXIST, "Học sinh"));
        }

        [Fact]
        public void Should_Have_Error_When_SemesterId_Does_Not_Exist()
        {
            var model = new PupilFeedbackDTO { PupilId = 1, SemesterId = 999, Description = "Feedback" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.SemesterId).WithErrorMessage(StringHelper.FormatMessage(Messages.NOT_EXIST, "Học kỳ"));
        }

        [Fact]
        public void Should_Have_Error_When_Description_Is_Empty()
        {
            // Arrange
            var model = new PupilFeedbackDTO { PupilId = 1, SemesterId = 1, Description = "" };

            // Act
            var result = _validator.TestValidate(model);

            // Assert
            result.ShouldHaveValidationErrorFor(x => x.Description)
                .WithErrorMessage(StringHelper.FormatMessage(Messages.REQUIRED, "Nội dung"));
        }


        [Fact]
        public void Should_Have_Error_When_Description_Exceeds_MaxLength()
        {
            // Arrange
            var model = new PupilFeedbackDTO
            {
                PupilId = 1,
                SemesterId = 1,
                Description = new string('a', 301)
            };

            // Act
            var result = _validator.TestValidate(model);

            // Assert
            result.ShouldHaveValidationErrorFor(x => x.Description)
                .WithErrorMessage(StringHelper.FormatMaxLengthMessage(Messages.MAX_LENGTH, "Nội dung", 300));
        }


        [Fact]
        public void Should_Have_Error_When_Feedback_Already_Exists_For_Pupil_And_Semester()
        {
            var model = new PupilFeedbackDTO { PupilId = 1, SemesterId = 1, Description = "Duplicate feedback", CreatedDate = null };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Description).WithErrorMessage(StringHelper.FormatMessage(Messages.IS_EXIST, "Phản hồi cho học sinh và học kỳ này"));
        }

        [Fact]
        public void Should_Have_Error_When_Status_Is_Invalid()
        {
            var model = new PupilFeedbackDTO { PupilId = 1, SemesterId = 1, Description = "Feedback", Status = 999 };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Status).WithErrorMessage(StringHelper.FormatMessage(Messages.INVALID, "Trạng thái phản hồi"));
        }

    }
}
