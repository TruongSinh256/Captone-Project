﻿using FluentValidation.TestHelper;
using Microsoft.EntityFrameworkCore;
using sep.backend.v1.Common.Const;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.Helpers;
using sep.backend.v1.Validators;
using Xunit;
using sep.backend.v1.DTOs;
using Microsoft.AspNetCore.Http;
using sep.backend.v1.Extensions.EF;

namespace sep.test.v1.Validators
{
    public class PupilUpdateProfileValidatorTest
    {
        private readonly PupilUpdateProfileValidator _validator;
        private readonly ApplicationContext _context;

        public PupilUpdateProfileValidatorTest()
        {
            var options = new DbContextOptionsBuilder<ApplicationContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationContext(options);

            _context.SaveChanges();

            _validator = new PupilUpdateProfileValidator(_context);
        }

        [Fact]
        public void Should_Have_Error_When_FirstName_Is_Empty()
        {
            var model = new UpdateProfilePupilDTO { FirstName = "" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.FirstName)
                .WithErrorMessage(Messages.NAME_REQUIRED);
        }

        [Fact]
        public void Should_Have_Error_When_FirstName_Exceeds_MaxLength()
        {
            var model = new UpdateProfilePupilDTO { FirstName = new string('a', 51) };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.FirstName)
                .WithErrorMessage(Messages.NAME_LENGTH);
        }

        [Fact]
        public void Should_Have_Error_When_FirstName_Has_Invalid_Characters()
        {
            var model = new UpdateProfilePupilDTO { FirstName = "John123" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.FirstName)
                .WithErrorMessage(Messages.NAME_LETTER);
        }

        [Fact]
        public void Should_Have_Error_When_DonorPhoneNumber_Is_Empty()
        {
            var model = new UpdateProfilePupilDTO { DonorPhoneNumber = "" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.DonorPhoneNumber)
                .WithErrorMessage(Messages.PHONE_NUMBER_REQUIRED);
        }

        [Fact]
        public void Should_Have_Error_When_DonorPhoneNumber_Is_Invalid()
        {
            var model = new UpdateProfilePupilDTO { DonorPhoneNumber = "1234567890" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.DonorPhoneNumber)
                .WithErrorMessage(Messages.PHONE_NUMBER_INVALID);
        }

        [Fact]
        public void Should_Have_Error_When_DateOfBirth_Is_Empty()
        {
            var model = new UpdateProfilePupilDTO { DateOfBirth = null };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.DateOfBirth)
                .WithErrorMessage(Messages.DATE_OF_BIRTH_REQUIRED);
        }

        [Fact]
        public void Should_Have_Error_When_DateOfBirth_Is_In_The_Future()
        {
            var model = new UpdateProfilePupilDTO { DateOfBirth = DateTime.Now.AddYears(1) };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.DateOfBirth)
                .WithErrorMessage(Messages.DATE_OF_BIRTH_IN_THE_PAST);
        }

        [Fact]
        public void Should_Have_Error_When_Address_Is_Empty()
        {
            var model = new UpdateProfilePupilDTO { Address = "" };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Address)
                .WithErrorMessage(Messages.ADDRESS_REQUIRED);
        }

        [Fact]
        public void Should_Have_Error_When_Image_Is_Invalid_Type()
        {
            var model = new UpdateProfilePupilDTO
            {
                Image = new FormFile(null, 0, 0, "file", "file.txt")
            };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Image)
                .WithErrorMessage("Các file hợp lệ PNG, JPG, JPEG, and GIF.");
        }

        [Fact]
        public void Should_Have_Error_When_Image_Is_Larger_Than_MaxSize()
        {
            var model = new UpdateProfilePupilDTO
            {
                Image = new FormFile(null, 0, 6 * 1024 * 1024, "file", "image.jpg") 
            };
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(x => x.Image)
                .WithErrorMessage("File vượt quá dung lượng 5MB.");
        }

        [Fact]
        public void Should_Not_Have_Error_When_Model_Is_Valid()
        {
            var model = new UpdateProfilePupilDTO
            {
                FirstName = "John",
                LastName = "Doe",
                DonorName = "Donor Name",
                DonorPhoneNumber = "0901234567",
                DateOfBirth = DateTime.Now.AddYears(-10),
                Address = "Valid address",
                Image = null
            };
            var result = _validator.TestValidate(model);
            result.ShouldNotHaveAnyValidationErrors();
        }

    }
}
