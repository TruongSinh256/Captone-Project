﻿using FluentValidation.TestHelper;
using sep.backend.v1.Helpers;
using sep.backend.v1.Requests.Auth;
using sep.backend.v1.Validators;
using sep.backend.v1.Common.Const;
using Xunit;
using System.Reflection;

namespace sep.test.v1.Validation;

public class LoginRequestValidatorTest
{
    private readonly LoginRequestValidator _validator;

    public LoginRequestValidatorTest()
    {
        _validator = new LoginRequestValidator();
    }

    [Fact]
    public void Should_Have_Error_When_Email_Is_Empty()
    {
        var model = new LoginRequest { Email = string.Empty, Password = "password", Mode = 1 };
        var result = _validator.TestValidate(model);
        result.ShouldHaveValidationErrorFor(x => x.Email).WithErrorMessage(sep.backend.v1.Common.Const.Messages.EMAIL_REQUIRED);
    }

    [Fact]
    public void Should_Have_Error_When_Password_Is_Empty()
    {
        var model = new LoginRequest { Email = "test@example.com", Password = string.Empty, Mode = 1 };
        var result = _validator.TestValidate(model);
        result.ShouldHaveValidationErrorFor(x => x.Password).WithErrorMessage(sep.backend.v1.Common.Const.Messages.PASSWORD_REQUIRED);
    }

    [Fact]
    public void Should_Have_Error_When_Mode_Is_Invalid()
    {
        var model = new LoginRequest { Email = "test@example.com", Password = "password", Mode = -1 };
        var result = _validator.TestValidate(model);
        result.ShouldHaveValidationErrorFor(x => x.Mode)
            .WithErrorMessage(StringHelper.FormatMessage(sep.backend.v1.Common.Const.Messages.INVALID, "Vai trò đăng nhập"));
    }

    [Fact]
    public void Should_Not_Have_Error_When_Request_Is_Valid()
    {
        var model = new LoginRequest { Email = "test@example.com", Password = "password", Mode = 1 };
        var result = _validator.TestValidate(model);
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Should_Return_True_For_Valid_Mode()
    {
        var method = typeof(LoginRequestValidator).GetMethod("BeValidStatusAccount", BindingFlags.NonPublic | BindingFlags.Instance);
        var result = (bool)method.Invoke(_validator, new object[] { 1 });
        Assert.True(result);
    }

    [Fact]
    public void Should_Return_False_For_Invalid_Mode()
    {
        var method = typeof(LoginRequestValidator).GetMethod("BeValidStatusAccount", BindingFlags.NonPublic | BindingFlags.Instance);
        var result = (bool)method.Invoke(_validator, new object[] { -1 });
        Assert.False(result);
    }
}