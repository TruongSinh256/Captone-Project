using System.Threading.Tasks;
using Moq;
using Xunit;
using sep.backend.v1.Services;
using sep.backend.v1.Services.UnitOfWork;
using sep.backend.v1.DTOs;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.Exceptions;
using sep.backend.v1.Helpers;
using sep.backend.v1.Services.IRepositories;

namespace sep.test.v1.Services
{
    public class InvoiceServiceTest
    {
        private readonly Mock<IUnitOfWork> _unitOfWorkMock;
        private readonly Mock<IAutoMapper> _mapperMock;
        private readonly InvoiceService _invoiceService;

        public InvoiceServiceTest()
        {
            _unitOfWorkMock = new Mock<IUnitOfWork>();
            _mapperMock = new Mock<IAutoMapper>();
            _invoiceService = new InvoiceService(_unitOfWorkMock.Object, _mapperMock.Object, null, null);
        }

        [Fact]
        public async Task GetInvoiceByIdAsync_ShouldReturnInvoiceDTO_WhenInvoiceExists()
        {
            var invoiceId = 1;
            var invoice = new Invoice { Id = invoiceId };
            var invoiceDTO = new InvoiceDTO { Id = invoiceId };

            _unitOfWorkMock.Setup(uow => uow.InvoiceRepository.GetInvoiceByIdAsync(invoiceId))
                .ReturnsAsync(invoice);
            _mapperMock.Setup(mapper => mapper.Map<Invoice, InvoiceDTO>(invoice))
                .Returns(invoiceDTO);

            var result = await _invoiceService.GetInvoiceByIdAsync(invoiceId);
            Assert.NotNull(result);
            Assert.Equal(invoiceId, result.Id);
        }

        [Fact]
        public async Task GetInvoiceByIdAsync_ShouldThrowNotFoundException_WhenInvoiceDoesNotExist()
        {
            var invoiceId = 1;

            _unitOfWorkMock.Setup(uow => uow.InvoiceRepository.GetInvoiceByIdAsync(invoiceId))
                .ReturnsAsync((Invoice)null);

            await Assert.ThrowsAsync<NotFoundException>(() => _invoiceService.GetInvoiceByIdAsync(invoiceId));
        }
    }
}