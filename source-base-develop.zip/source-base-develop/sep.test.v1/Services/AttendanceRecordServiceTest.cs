﻿using Moq;
using Xunit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using sep.backend.v1.Services;
using sep.backend.v1.Services.UnitOfWork;
using sep.backend.v1.DTOs;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.Exceptions;
using sep.backend.v1.Helpers;
using sep.backend.v1.Extensions.EF;

namespace sep.test.v1.Services
{
    public class AttendanceRecordServiceTest
    {
        private readonly Mock<IUnitOfWork> _unitOfWorkMock;
        private readonly Mock<IAutoMapper> _mapperMock;
        private readonly Mock<ApplicationContext> _contextMock;
        private readonly AttendanceRecordService _attendanceRecordService;

        public AttendanceRecordServiceTest()
        {
            _unitOfWorkMock = new Mock<IUnitOfWork>();
            _mapperMock = new Mock<IAutoMapper>();
            _contextMock = new Mock<ApplicationContext>();

            _attendanceRecordService = new AttendanceRecordService(
                _unitOfWorkMock.Object,
                _mapperMock.Object,
                _contextMock.Object
            );
        }

        [Fact]
        public async Task CreateAttendanceRecords_ShouldAddRecordsSuccessfully()
        {
            // Arrange
            var attendanceRecordDTOs = new List<AttendanceRecordDTO>
            {
                new AttendanceRecordDTO { PupilId = 1, AttendanceType = 1, IsAttend = true },
                new AttendanceRecordDTO { PupilId = 2, AttendanceType = 1, IsAttend = false }
            };

            var attendanceRecords = new List<AttendanceRecord>
            {
                new AttendanceRecord { PupilId = 1, AttendanceType = 1, IsAttend = true },
                new AttendanceRecord { PupilId = 2, AttendanceType = 1, IsAttend = false }
            };

            _mapperMock.Setup(mapper => mapper.Map<List<AttendanceRecordDTO>, List<AttendanceRecord>>(attendanceRecordDTOs))
                .Returns(attendanceRecords);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<AttendanceRecord>().BulkInsert(attendanceRecords))
                .ReturnsAsync(true);

            // Act
            var result = await _attendanceRecordService.CreateAttendanceRecords(attendanceRecordDTOs);

            // Assert
            Assert.True(result);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

        [Fact]
        public async Task CreateAttendanceRecords_ShouldThrowNotFoundException_WhenNoRecordsProvided()
        {
            // Arrange
            var attendanceRecordDTOs = new List<AttendanceRecordDTO>();

            _mapperMock.Setup(mapper => mapper.Map<List<AttendanceRecordDTO>, List<AttendanceRecord>>(attendanceRecordDTOs))
                .Returns(new List<AttendanceRecord>());

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _attendanceRecordService.CreateAttendanceRecords(attendanceRecordDTOs));
        }

        [Fact]
        public async Task GetAttendanceRecords_ShouldReturnRecords_WhenRecordsExist()
        {
            // Arrange
            var entityId = 1;
            var session = 1;
            var type = 1;
            var semesterId = 1;
            var date = DateTime.Now;

            var pupils = new List<Pupil>
    {
        new Pupil
        {
            Id = 1,
            AttendanceRecords = new List<AttendanceRecord>
            {
                new AttendanceRecord
                {
                    AttendanceSession = 1,
                    AttendanceType = 1,
                    CreatedDate = date,
                    IsAttend = true,
                    ClassId = 1,
                    Pupil = new Pupil { Id = 1 } // Ensure Pupil reference is not null
                }
            }
        }
    };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Pupil>().GetMulti(It.IsAny<System.Linq.Expressions.Expression<Func<Pupil, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(pupils);

            _mapperMock.Setup(mapper => mapper.Map<List<AttendanceRecord>, List<AttendanceRecordViewDTO>>(It.IsAny<List<AttendanceRecord>>()))
                .Returns(new List<AttendanceRecordViewDTO>
                {
            new AttendanceRecordViewDTO { PupilId = 1, IsAttend = true }
                });

            // Act
            var result = await _attendanceRecordService.GetAttendanceRecords(entityId, session, type, semesterId, date);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
        }


        [Fact]
        public async Task UpdateAttendanceRecords_ShouldUpdateRecordsSuccessfully()
        {
            // Arrange
            var attendanceRecordDTOs = new List<AttendanceRecordDTO>
            {
                new AttendanceRecordDTO { PupilId = 1, AttendanceType = 1, IsAttend = true }
            };

            var attendanceRecords = new List<AttendanceRecord>
            {
                new AttendanceRecord { PupilId = 1, AttendanceType = 1, IsAttend = true }
            };

            _mapperMock.Setup(mapper => mapper.Map<List<AttendanceRecordDTO>, List<AttendanceRecord>>(attendanceRecordDTOs))
                .Returns(attendanceRecords);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<AttendanceRecord>().BulkUpdate(attendanceRecords))
                .ReturnsAsync(true);

            // Act
            var result = await _attendanceRecordService.UpdateAttendanceRecords(attendanceRecordDTOs);

            // Assert
            Assert.True(result);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

        [Fact]
        public async Task UpdateAttendanceRecords_ShouldThrowNotFoundException_WhenNoRecordsProvided()
        {
            // Arrange
            var attendanceRecordDTOs = new List<AttendanceRecordDTO>();

            _mapperMock.Setup(mapper => mapper.Map<List<AttendanceRecordDTO>, List<AttendanceRecord>>(attendanceRecordDTOs))
                .Returns(new List<AttendanceRecord>());

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _attendanceRecordService.UpdateAttendanceRecords(attendanceRecordDTOs));
        }
        [Fact]
        public async Task GetAttendanceRecords_ShouldReturnEmpty_WhenNoRecordsMatch()
        {
            // Arrange
            var entityId = 1;
            var session = 1;
            var type = 1;
            var semesterId = 1;
            var date = DateTime.Now;

            var pupils = new List<Pupil>
    {
        new Pupil
        {
            Id = 1,
            AttendanceRecords = new List<AttendanceRecord>
            {
                new AttendanceRecord
                {
                    AttendanceSession = 2, // Different session
                    AttendanceType = 2,   // Different type
                    CreatedDate = date.AddDays(-1), // Different date
                    ClassId = 2           // Different entityId
                }
            }
        }
    };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Pupil>().GetMulti(It.IsAny<System.Linq.Expressions.Expression<Func<Pupil, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(pupils);

            _mapperMock.Setup(mapper => mapper.Map<List<AttendanceRecord>, List<AttendanceRecordViewDTO>>(It.IsAny<List<AttendanceRecord>>()))
                .Returns(new List<AttendanceRecordViewDTO>());

            // Act
            var result = await _attendanceRecordService.GetAttendanceRecords(entityId, session, type, semesterId, date);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetAttendanceRecords_ShouldThrowNotFoundException_WhenNoPupilsExist()
        {
            // Arrange
            var entityId = 1;
            var session = 1;
            var type = 1;
            var semesterId = 1;
            var date = DateTime.Now;

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Pupil>().GetMulti(It.IsAny<System.Linq.Expressions.Expression<Func<Pupil, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(new List<Pupil>());

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _attendanceRecordService.GetAttendanceRecords(entityId, session, type, semesterId, date));
        }

        [Fact]
        public async Task CreateAttendanceRecords_ShouldCreateRecordsSuccessfully()
        {
            // Arrange
            var attendanceRecords = new List<AttendanceRecordDTO>
    {
        new AttendanceRecordDTO { PupilId = 1, AttendanceSession = 1, AttendanceType = 1, IsAttend = true, ClassId = 1 }
    };

            _mapperMock.Setup(mapper => mapper.Map<List<AttendanceRecordDTO>, List<AttendanceRecord>>(attendanceRecords))
                .Returns(new List<AttendanceRecord>
                {
            new AttendanceRecord { PupilId = 1, AttendanceSession = 1, AttendanceType = 1, IsAttend = true, ClassId = 1 }
                });

            _unitOfWorkMock.Setup(uow => uow.GetRepository<AttendanceRecord>().BulkInsert(It.IsAny<List<AttendanceRecord>>()))
                .ReturnsAsync(true);

            // Act
            var result = await _attendanceRecordService.CreateAttendanceRecords(attendanceRecords);

            // Assert
            Assert.True(result);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }


    }
}
