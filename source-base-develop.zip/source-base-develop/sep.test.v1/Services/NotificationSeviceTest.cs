﻿using Moq;
using Xunit;
using sep.backend.v1.Services;
using sep.backend.v1.Services.UnitOfWork;
using sep.backend.v1.DTOs;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.Exceptions;
using sep.backend.v1.Helpers;
using sep.backend.v1.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.Linq.Expressions;

namespace sep.test.v1.Services
{
    public class NotificationServiceTest
    {
        private readonly Mock<IUnitOfWork> _unitOfWorkMock;
        private readonly Mock<IAutoMapper> _mapperMock;
        private readonly Mock<IEmailService> _emailServiceMock;
        private readonly NotificationService _notificationService;

        public NotificationServiceTest()
        {
            _unitOfWorkMock = new Mock<IUnitOfWork>();
            _mapperMock = new Mock<IAutoMapper>();
            _emailServiceMock = new Mock<IEmailService>();
            _notificationService = new NotificationService(_unitOfWorkMock.Object, _mapperMock.Object, _emailServiceMock.Object);
        }

        [Fact]
        public async Task GetNotificationAsync_ShouldReturnNotification_WhenExists()
        {
            // Arrange
            var notificationId = 1;
            var notificationEntity = new Notifications { Id = notificationId, Title = "Test Notification" };
            var notificationDTO = new DetailNotificationDTO { Id = notificationId, Title = "Test Notification" };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Notifications>().GetSingleByCondition(It.IsAny<Expression<Func<Notifications, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(notificationEntity);

            _mapperMock.Setup(mapper => mapper.Map<Notifications, DetailNotificationDTO>(notificationEntity))
                .Returns(notificationDTO);

            // Act
            var result = await _notificationService.GetNotificationAsync(notificationId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(notificationDTO.Id, result.Id);
            Assert.Equal(notificationDTO.Title, result.Title);
        }

        [Fact]
        public async Task GetNotificationAsync_ShouldThrowNotFoundException_WhenDoesNotExist()
        {
            // Arrange
            _unitOfWorkMock.Setup(uow => uow.GetRepository<Notifications>().GetSingleByCondition(It.IsAny<Expression<Func<Notifications, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync((Notifications)null);

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _notificationService.GetNotificationAsync(1));
        }
        [Fact]
        public async Task UpdateNotificationAsync_ShouldUpdateNotificationDetails()
        {
            // Arrange
            var updateNotificationDTO = new UpdateNotificationDTO
            {
                Id = 1,
                Title = "Updated Title",
                Descriptions = "Updated Description",
                CategoryId = 1
            };

            var existingNotification = new Notifications
            {
                Id = 1,
                Title = "Old Title",
                Descriptions = "Old Description",
                Images = new List<NotificationImage>()
            };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Notifications>().GetSingleByCondition(It.IsAny<Expression<Func<Notifications, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(existingNotification);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Notifications>().Update(existingNotification))
                .ReturnsAsync(true);

            // Act
            var result = await _notificationService.UpdateNotificationAsync(updateNotificationDTO);

            // Assert
            Assert.True(result);
            Assert.Equal(updateNotificationDTO.Title, existingNotification.Title);
            Assert.Equal(updateNotificationDTO.Descriptions, existingNotification.Descriptions);
        }

    }
}