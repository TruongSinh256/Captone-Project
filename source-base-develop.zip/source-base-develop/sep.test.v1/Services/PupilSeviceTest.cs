﻿using Moq;
using Xunit;
using System;
using System.Threading.Tasks;
using sep.backend.v1.Services;
using sep.backend.v1.Services.UnitOfWork;
using sep.backend.v1.DTOs;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.Exceptions;
using sep.backend.v1.Helpers;
using Microsoft.AspNetCore.Hosting;

namespace sep.test.v1.Services
{
    public class PupilServiceTest
    {
        private readonly Mock<IUnitOfWork> _unitOfWorkMock;
        private readonly Mock<IAutoMapper> _mapperMock;
        private readonly Mock<IWebHostEnvironment> _environmentMock;
        private readonly PupilService _pupilService;

        public PupilServiceTest()
        {
            _unitOfWorkMock = new Mock<IUnitOfWork>();
            _mapperMock = new Mock<IAutoMapper>();
            _environmentMock = new Mock<IWebHostEnvironment>();

            _pupilService = new PupilService(_unitOfWorkMock.Object, _mapperMock.Object, _environmentMock.Object);
        }

        [Fact]
        public async Task GetProfilePupilAsync_ShouldReturnProfile_WhenPupilExists()
        {
            // Arrange
            var pupilId = 1;
            var pupilEntity = new Pupil
            {
                Id = pupilId,
                FirstName = "John",
                LastName = "Doe",
                Address = "123 Main St"
            };

            var pupilProfileDTO = new ProfilePupilDTO
            {
                Id = pupilId,
                FirstName = "John",
                LastName = "Doe",
                Address = "123 Main St"
            };

            _unitOfWorkMock.Setup(uow => uow.PupilRepository.GetPupilProfile(pupilId))
                .ReturnsAsync(pupilEntity);

            _mapperMock.Setup(mapper => mapper.Map<Pupil, ProfilePupilDTO>(pupilEntity))
                .Returns(pupilProfileDTO);

            // Act
            var result = await _pupilService.GetProfilePupilAsync(pupilId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(pupilProfileDTO.Id, result.Id);
            Assert.Equal(pupilProfileDTO.FirstName, result.FirstName);
            Assert.Equal(pupilProfileDTO.LastName, result.LastName);
        }

        [Fact]
        public async Task GetProfilePupilAsync_ShouldThrowNotFoundException_WhenPupilDoesNotExist()
        {
            // Arrange
            var pupilId = 1;
            _unitOfWorkMock.Setup(uow => uow.PupilRepository.GetPupilProfile(pupilId))
                .ReturnsAsync((Pupil)null);

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _pupilService.GetProfilePupilAsync(pupilId));
        }

        [Fact]
        public async Task UpdateProfilePupilAsync_ShouldUpdateProfileSuccessfully()
        {
            // Arrange
            var updateProfilePupilDto = new UpdateProfilePupilDTO
            {
                Id = 1,
                FirstName = "Jane",
                LastName = "Smith",
                Gender = false,
                DonorName = "Parent",
                DonorPhoneNumber = "1234567890",
                Address = "456 Elm St",
                DateOfBirth = new DateTime(2010, 1, 1)
            };

            var pupilEntity = new Pupil
            {
                Id = 1,
                FirstName = "Old Name",
                LastName = "Old Last Name",
                Gender = true,
                DonorName = "Old Parent",
                DonorPhoneNumber = "0987654321",
                Address = "Old Address",
                DateOfBirth = new DateTime(2000, 1, 1)
            };

            _unitOfWorkMock.Setup(uow => uow.PupilRepository.GetById(updateProfilePupilDto.Id))
                .ReturnsAsync(pupilEntity);

            _unitOfWorkMock.Setup(uow => uow.PupilRepository.Update(pupilEntity))
                .ReturnsAsync(true);

            // Act
            var result = await _pupilService.UpdateProfilePupilAsync(updateProfilePupilDto);

            // Assert
            Assert.True(result);
            Assert.Equal(updateProfilePupilDto.FirstName, pupilEntity.FirstName);
            Assert.Equal(updateProfilePupilDto.LastName, pupilEntity.LastName);
            Assert.Equal(updateProfilePupilDto.Gender, pupilEntity.Gender);
            Assert.Equal(updateProfilePupilDto.DonorName, pupilEntity.DonorName);
            Assert.Equal(updateProfilePupilDto.DonorPhoneNumber, pupilEntity.DonorPhoneNumber);
            Assert.Equal(updateProfilePupilDto.Address, pupilEntity.Address);
            Assert.Equal(updateProfilePupilDto.DateOfBirth, pupilEntity.DateOfBirth);

            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

    }
}
