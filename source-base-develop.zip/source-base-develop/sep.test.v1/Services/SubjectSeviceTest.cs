﻿using Moq;
using Xunit;
using sep.backend.v1.Services;
using sep.backend.v1.Services.UnitOfWork;
using sep.backend.v1.DTOs;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.Exceptions;
using sep.backend.v1.Helpers;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sep.test.v1.Services
{
    public class SubjectServiceTest
    {
        private readonly Mock<IUnitOfWork> _unitOfWorkMock;
        private readonly Mock<IAutoMapper> _mapperMock;
        private readonly SubjectService _subjectService;

        public SubjectServiceTest()
        {
            _unitOfWorkMock = new Mock<IUnitOfWork>();
            _mapperMock = new Mock<IAutoMapper>();
            _subjectService = new SubjectService(_unitOfWorkMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetAll_ShouldReturnSubjects_WhenSubjectsExist()
        {
            // Arrange
            var schoolId = 1;
            var subjects = new List<Subject>
            {
                new Subject { Id = 1, Name = "Math", SchoolId = schoolId },
                new Subject { Id = 2, Name = "Science", SchoolId = schoolId }
            };

            var subjectDTOs = subjects.Select(s => new SubjectDTO { Id = s.Id, Name = s.Name }).ToList();

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Subject>().GetMulti(It.IsAny<System.Linq.Expressions.Expression<System.Func<Subject, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(subjects);

            _mapperMock.Setup(mapper => mapper.Map<Subject, SubjectDTO>(It.IsAny<Subject>()))
                .Returns((Subject subject) => new SubjectDTO { Id = subject.Id, Name = subject.Name });

            // Act
            var result = await _subjectService.GetAll(schoolId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(subjectDTOs.Count, result.Count);
            Assert.Equal(subjectDTOs[0].Name, result[0].Name);
        }

        [Fact]
        public async Task GetAll_ShouldReturnNull_WhenNoSubjectsExist()
        {
            // Arrange
            var schoolId = 1;
            _unitOfWorkMock.Setup(uow => uow.GetRepository<Subject>().GetMulti(It.IsAny<System.Linq.Expressions.Expression<System.Func<Subject, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(new List<Subject>());

            // Act
            var result = await _subjectService.GetAll(schoolId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task CreateSubject_ShouldCreateSubjectSuccessfully()
        {
            // Arrange
            var schoolId = 1;
            var subjectDTO = new SubjectDTO { Name = "Math", Code = "MATH101" };
            var subjectEntity = new Subject { Id = 1, Name = "Math", Code = "MATH101", SchoolId = schoolId };

            _mapperMock.Setup(mapper => mapper.Map<SubjectDTO, Subject>(subjectDTO))
                .Returns(subjectEntity);

            _mapperMock.Setup(mapper => mapper.Map<Subject, SubjectDTO>(subjectEntity))
                .Returns(subjectDTO);

            _unitOfWorkMock.Setup(uow => uow.SubjectRepository.Add(subjectEntity))
                .ReturnsAsync(true);

            // Act
            var result = await _subjectService.CreateSubject(subjectDTO, schoolId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(subjectDTO.Name, result.Name);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

        [Fact]
        public async Task UpdateSubject_ShouldUpdateSubjectSuccessfully()
        {
            // Arrange
            var subjectId = 1;
            var subjectDTO = new SubjectDTO { Id = subjectId, Name = "Updated Math", Code = "MATH102" };
            var subjectEntity = new Subject { Id = subjectId, Name = "Math", Code = "MATH101" };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Subject>().GetById(subjectId))
                .ReturnsAsync(subjectEntity);

            _mapperMock.Setup(mapper => mapper.Map<Subject, SubjectDTO>(subjectEntity))
                .Returns(subjectDTO);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Subject>().Update(subjectEntity))
                .ReturnsAsync(true);

            // Act
            var result = await _subjectService.UpdateSubject(subjectId, subjectDTO);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(subjectDTO.Name, result.Name);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

        [Fact]
        public async Task UpdateSubject_ShouldThrowNotFoundException_WhenSubjectDoesNotExist()
        {
            // Arrange
            var subjectId = 1;
            var subjectDTO = new SubjectDTO { Id = subjectId, Name = "Updated Math", Code = "MATH102" };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Subject>().GetById(subjectId))
                .ReturnsAsync((Subject)null);

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _subjectService.UpdateSubject(subjectId, subjectDTO));
        }

        [Fact]
        public async Task DeleteSubject_ShouldDeleteSubjectSuccessfully()
        {
            // Arrange
            var subjectId = 1;
            var schoolId = 1;
            var subjectEntity = new Subject { Id = subjectId, SchoolId = schoolId };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Subject>().Where(It.IsAny<System.Linq.Expressions.Expression<System.Func<Subject, bool>>>()))
                .Returns(new List<Subject> { subjectEntity }.AsQueryable);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Subject>().Delete(subjectId))
                .ReturnsAsync(true);

            // Act
            var result = await _subjectService.DeleteSubject(subjectId, schoolId);

            // Assert
            Assert.True(result);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

        [Fact]
        public async Task DeleteSubject_ShouldThrowNotFoundException_WhenSubjectDoesNotExist()
        {
            // Arrange
            var subjectId = 1;
            var schoolId = 1;

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Subject>().Where(It.IsAny<System.Linq.Expressions.Expression<System.Func<Subject, bool>>>()))
                .Returns(Enumerable.Empty<Subject>().AsQueryable);

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _subjectService.DeleteSubject(subjectId, schoolId));
        }

        [Fact]
        public async Task DeleteSubject_ShouldThrowConflictException_WhenSubjectHasRelatedEntities()
        {
            // Arrange
            var subjectId = 1;
            var schoolId = 1;
            var subjectEntity = new Subject
            {
                Id = subjectId,
                SchoolId = schoolId,
                PupilFeedbacks = new List<PupilFeedback> { new PupilFeedback() }
            };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Subject>().Where(It.IsAny<System.Linq.Expressions.Expression<System.Func<Subject, bool>>>()))
                .Returns(new List<Subject> { subjectEntity }.AsQueryable);

            // Act & Assert
            await Assert.ThrowsAsync<ConflictException>(() => _subjectService.DeleteSubject(subjectId, schoolId));
        }
    }
}
