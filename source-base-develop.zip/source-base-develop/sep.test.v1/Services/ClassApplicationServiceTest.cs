﻿using Xunit;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using sep.backend.v1.Services;
using sep.backend.v1.Services.UnitOfWork;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.DTOs;
using sep.backend.v1.Exceptions;
using sep.backend.v1.Services.IServices;

namespace sep.test.v1.Services
{
    public class ClassApplicationServiceTest
    {
        private readonly Mock<IUnitOfWork> _unitOfWorkMock;
        private readonly Mock<IAutoMapper> _mapperMock;
        private readonly Mock<IEmailService> _emailServiceMock;
        private readonly Mock<ISemesterService> _semesterServiceMock;
        private readonly Mock<IClassService> _classServiceMock;
        private readonly ClassApplicationService _classApplicationService;

        public ClassApplicationServiceTest()
        {
            _unitOfWorkMock = new Mock<IUnitOfWork>();
            _mapperMock = new Mock<IAutoMapper>();
            _emailServiceMock = new Mock<IEmailService>();
            _semesterServiceMock = new Mock<ISemesterService>();
            _classServiceMock = new Mock<IClassService>();
            _classApplicationService = new ClassApplicationService(
                _unitOfWorkMock.Object,
                _mapperMock.Object,
                _emailServiceMock.Object,
                _semesterServiceMock.Object,
                _classServiceMock.Object
            );
        }

        [Fact]
        public async Task CreateClassApplication_ShouldThrowNotFoundException_WhenClassEnrollmentNotFound()
        {
            // Arrange
            var model = new CreateAndUpdateClassApplicationDTO { PupilId = 1, SemesterId = 1 };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<ClassEnrollment>()
                .GetSingleByCondition(It.IsAny<System.Linq.Expressions.Expression<Func<ClassEnrollment, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync((ClassEnrollment)null);

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _classApplicationService.CreateClassApplication(model, 1));
        }

        [Fact]
        public async Task DeleteClassApplication_ShouldDeleteSuccessfully()
        {
            // Arrange
            var applicationId = 1;
            var classApplication = new ClassApplication { Id = applicationId };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<ClassApplication>()
                .GetSingleByCondition(It.IsAny<System.Linq.Expressions.Expression<Func<ClassApplication, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(classApplication);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<ClassApplication>().Delete(applicationId))
                .ReturnsAsync(true);

            // Act
            var result = await _classApplicationService.DeleteClassApplication(applicationId);

            // Assert
            Assert.True(result);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

        [Fact]
        public async Task DeleteClassApplication_ShouldThrowNotFoundException_WhenApplicationNotFound()
        {
            // Arrange
            var applicationId = 1;

            _unitOfWorkMock.Setup(uow => uow.GetRepository<ClassApplication>()
                .GetSingleByCondition(It.IsAny<System.Linq.Expressions.Expression<Func<ClassApplication, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync((ClassApplication)null);

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _classApplicationService.DeleteClassApplication(applicationId));
        }

        [Fact]
        public async Task GetClassApplicationByClassId_ShouldReturnApplications()
        {
            // Arrange
            var classId = 1;
            var semesterId = 1;
            var applications = new List<ClassApplication>
            {
                new ClassApplication { Id = 1, PupilId = 1, SemesterId = semesterId, ApplicationCategoryId = 1 }
            };

            var applicationDTOs = new List<GetClassAppicationDetailDTO>
            {
                new GetClassAppicationDetailDTO { Id = 1, PupilId = 1, SemesterId = semesterId }
            };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Pupil>()
                .GetMulti(It.IsAny<System.Linq.Expressions.Expression<Func<Pupil, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(new List<Pupil>
                {
                    new Pupil { Id = 1, ClassApplications = applications }
                });

            _mapperMock.Setup(mapper => mapper.Map<List<ClassApplication>, List<GetClassAppicationDetailDTO>>(applications))
                .Returns(applicationDTOs);

            // Act
            var result = await _classApplicationService.GetClassApplicationByClassId(classId, semesterId, null);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
        }

        [Fact]
        public async Task GetClassApplicationByPupilId_ShouldReturnApplications()
        {
            // Arrange
            var pupilId = 1;
            var semesterId = 1;
            var applications = new List<ClassApplication>
            {
                new ClassApplication { Id = 1, PupilId = pupilId, SemesterId = semesterId }
            };

            var applicationDTOs = new List<GetClassAppicationDetailDTO>
            {
                new GetClassAppicationDetailDTO { Id = 1, PupilId = pupilId, SemesterId = semesterId }
            };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<ClassApplication>()
                .GetMulti(It.IsAny<System.Linq.Expressions.Expression<Func<ClassApplication, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(applications);

            _mapperMock.Setup(mapper => mapper.Map<List<ClassApplication>, List<GetClassAppicationDetailDTO>>(applications))
                .Returns(applicationDTOs);

            // Act
            var result = await _classApplicationService.GetClassApplicationByPupilId(pupilId, semesterId);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
        }
        [Fact]
        public async Task ResponeClassApplication_ShouldThrowNotFoundException_WhenClassApplicationDoesNotExist()
        {
            // Arrange
            var model = new ResponeClassApplicationDTO { Id = 1, Response = "Approved", Status = 1 };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<ClassApplication>()
                .GetSingleByCondition(It.IsAny<System.Linq.Expressions.Expression<Func<ClassApplication, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync((ClassApplication)null);

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _classApplicationService.ResponeClassApplication(model));
            _unitOfWorkMock.Verify(uow => uow.GetRepository<ClassApplication>().Update(It.IsAny<ClassApplication>()), Times.Never);
        }

        [Fact]
        public async Task ResponeClassApplication_ShouldHandleMissingClassApplicationGracefully()
        {
            // Arrange
            var model = new ResponeClassApplicationDTO { Id = 999, Response = "Approved", Status = 1 };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<ClassApplication>()
                .GetSingleByCondition(It.IsAny<System.Linq.Expressions.Expression<Func<ClassApplication, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync((ClassApplication)null);

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _classApplicationService.ResponeClassApplication(model));
            _unitOfWorkMock.Verify(uow => uow.GetRepository<ClassApplication>().Update(It.IsAny<ClassApplication>()), Times.Never);
        }

    }
}
