﻿using Moq;
using Xunit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using sep.backend.v1.Services;
using sep.backend.v1.Services.UnitOfWork;
using sep.backend.v1.DTOs;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.Exceptions;
using sep.backend.v1.Helpers;
using System.Linq.Expressions;

namespace sep.test.v1.Services
{
    public class PupilScoreServiceTest
    {
        private readonly Mock<IUnitOfWork> _unitOfWorkMock;
        private readonly Mock<IAutoMapper> _mapperMock;
        private readonly PupilScoreService _pupilScoreService;

        public PupilScoreServiceTest()
        {
            _unitOfWorkMock = new Mock<IUnitOfWork>();
            _mapperMock = new Mock<IAutoMapper>();
            _pupilScoreService = new PupilScoreService(_unitOfWorkMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreatePupilScores_ShouldCreateScoresSuccessfully()
        {
            // Arrange
            var pupilScoreDTOs = new List<PupilScoreDTO>
            {
                new PupilScoreDTO { PupilId = 1, SubjectId = 1, Score = 9 },
                new PupilScoreDTO { PupilId = 2, SubjectId = 1, Score = 8 }
            };

            var pupilScoreEntities = pupilScoreDTOs.Select(dto => new PupilScore { PupilId = dto.PupilId, SubjectId = dto.SubjectId, Score = dto.Score }).ToList();

            _mapperMock.Setup(mapper => mapper.Map<List<PupilScoreDTO>, List<PupilScore>>(pupilScoreDTOs))
                .Returns(pupilScoreEntities);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<PupilScore>().BulkInsert(pupilScoreEntities))
                .ReturnsAsync(true);

            // Act
            var result = await _pupilScoreService.CreatePupilScores(pupilScoreDTOs);

            // Assert
            Assert.True(result);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

        
        [Fact]
        public async Task UpdatePupilScores_ShouldUpdateScoresSuccessfully()
        {
            // Arrange
            var updatedScores = new List<PupilScoreDTO>
            {
                new PupilScoreDTO { PupilId = 1, SubjectId = 1, Score = 90 },
                new PupilScoreDTO { PupilId = 2, SubjectId = 1, Score = 85 }
            };

            var updatedScoreEntities = updatedScores.Select(dto => new PupilScore { PupilId = dto.PupilId, SubjectId = dto.SubjectId, Score = dto.Score }).ToList();

            _mapperMock.Setup(mapper => mapper.Map<List<PupilScoreDTO>, List<PupilScore>>(updatedScores))
                .Returns(updatedScoreEntities);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<PupilScore>().BulkUpdate(updatedScoreEntities))
                .ReturnsAsync(true);

            // Act
            var result = await _pupilScoreService.UpdatePupilScores(updatedScores);

            // Assert
            Assert.True(result);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

        [Fact]
        public async Task GetPupilScores_ShouldReturnScoresSuccessfully()
        {
            // Arrange
            var entityId = 1;
            var semesterId = 1;
            var subjectId = 1;

            var pupils = new List<Pupil>
            {
                new Pupil
                {
                    Id = 1,
                    PupilScores = new List<PupilScore>
                    {
                        new PupilScore { SubjectId = 1, SemesterId = 1, Score = 95 }
                    }
                },
                new Pupil
                {
                    Id = 2,
                    PupilScores = new List<PupilScore>
                    {
                        new PupilScore { SubjectId = 1, SemesterId = 1, Score = 88 }
                    }
                }
            };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<Pupil>().GetMulti(
                It.IsAny<System.Linq.Expressions.Expression<Func<Pupil, bool>>>(),
                It.IsAny<string[]>()))
                .ReturnsAsync(pupils);

            _mapperMock.Setup(mapper => mapper.Map<List<PupilScore>, List<PupilScoreViewDTO>>(It.IsAny<List<PupilScore>>()))
                .Returns(new List<PupilScoreViewDTO>
                {
                    new PupilScoreViewDTO { PupilId = 1, Score = 95 },
                    new PupilScoreViewDTO { PupilId = 2, Score = 88 }
                });

            // Act
            var result = await _pupilScoreService.GetPupilScores(entityId, semesterId, subjectId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
        }

    }
}
