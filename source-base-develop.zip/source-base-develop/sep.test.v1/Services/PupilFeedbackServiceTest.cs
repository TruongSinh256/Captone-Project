﻿using Moq;
using Xunit;
using sep.backend.v1.Services;
using sep.backend.v1.Services.UnitOfWork;
using sep.backend.v1.DTOs;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.Exceptions;
using System.Collections.Generic;
using System.Threading.Tasks;
using sep.backend.v1.Services.IServices;

namespace sep.test.v1.Services
{
    public class PupilFeedbackServiceTest
    {
        private readonly Mock<IUnitOfWork> _unitOfWorkMock;
        private readonly Mock<IAutoMapper> _mapperMock;
        private readonly PupilFeedbackService _pupilFeedbackService;

        public PupilFeedbackServiceTest()
        {
            _unitOfWorkMock = new Mock<IUnitOfWork>();
            _mapperMock = new Mock<IAutoMapper>();
            var pupilFeedbackService = (IPupilFeedbackService)_pupilFeedbackService;
            _pupilFeedbackService = new PupilFeedbackService(_unitOfWorkMock.Object, _mapperMock.Object);
           

        }

        [Fact]
        public async Task CreatePupilFeedback_ShouldReturnTrue_WhenFeedbackIsCreatedSuccessfully()
        {
            // Arrange
            var feedbackDTO = new PupilFeedbackDTO { PupilId = 1, SemesterId = 1, Description = "Great student" };
            var feedbackEntity = new PupilFeedback { PupilId = 1, SemesterId = 1, Description = "Great student" };

            _mapperMock.Setup(mapper => mapper.Map<PupilFeedbackDTO, PupilFeedback>(feedbackDTO))
                .Returns(feedbackEntity);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<PupilFeedback>().Add(feedbackEntity))
                .ReturnsAsync(true);

            // Act
            var result = await _pupilFeedbackService.CreatePupilFeedback(feedbackDTO);

            // Assert
            Assert.True(result);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

        [Fact]
        public async Task CreatePupilFeedback_ShouldReturnFalse_WhenTransactionFails()
        {
            // Arrange
            var feedbackDTO = new PupilFeedbackDTO { PupilId = 1, SemesterId = 1, Description = "Great student" };
            var feedbackEntity = new PupilFeedback { PupilId = 1, SemesterId = 1, Description = "Great student" };

            _mapperMock.Setup(mapper => mapper.Map<PupilFeedbackDTO, PupilFeedback>(feedbackDTO))
                .Returns(feedbackEntity);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<PupilFeedback>().Add(feedbackEntity))
                .Throws(new System.Exception("Database error"));

            // Act
            var result = await _pupilFeedbackService.CreatePupilFeedback(feedbackDTO);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task DeletePupilFeedback_ShouldReturnTrue_WhenFeedbacksAreDeleted()
        {
            // Arrange
            var pupilId = 1;
            var semesterId = 1;

            _unitOfWorkMock.Setup(uow => uow.GetRepository<PupilFeedback>()
                .DeleteMulti(It.IsAny<System.Linq.Expressions.Expression<System.Func<PupilFeedback, bool>>>()))
                .Verifiable();

            // Act
            var result = await _pupilFeedbackService.DeletePupilFeedback(pupilId, semesterId);

            // Assert
            Assert.True(result);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

        [Fact]
        public async Task GetPupilFeedbacks_ShouldReturnFeedbackList_WhenFeedbacksExist()
        {
            // Arrange
            var pupilId = 1;

            var feedbacks = new List<PupilFeedback>
    {
        new PupilFeedback
        {
            Description = "Good behavior",
            Status = 1,
            CreatedDate = DateTime.Now,
            Semester = new Semester { Id = 1, SemesterName = "Semester 1" }
        },
        new PupilFeedback
        {
            Description = "Excellent",
            Status = 1,
            CreatedDate = DateTime.Now.AddMonths(-1),
            Semester = new Semester { Id = 2, SemesterName = "Semester 2" }
        }
    };

            _unitOfWorkMock.Setup(uow => uow.FeedbackRepository.GetAllFeedbacksOfPupil(pupilId))
                .ReturnsAsync(feedbacks);

            _mapperMock.Setup(mapper => mapper.Map<List<PupilFeedback>, List<PupilFeedbackDetailDTO>>(feedbacks))
                .Returns(new List<PupilFeedbackDetailDTO>
                {
            new PupilFeedbackDetailDTO
            {
                Description = "Good behavior",
                Status = 1,
                CreatedDate = feedbacks[0].CreatedDate,
                Semester = new ViewSemesterDTO { Id = 1, SemesterName = "Semester 1" }
            },
            new PupilFeedbackDetailDTO
            {
                Description = "Excellent",
                Status = 1,
                CreatedDate = feedbacks[1].CreatedDate,
                Semester = new ViewSemesterDTO { Id = 2, SemesterName = "Semester 2" }
            }
                });

            // Act
            var result = await _pupilFeedbackService.GetPupilFeedbacks(pupilId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
            Assert.Equal("Good behavior", result[0].Description);
            Assert.Equal("Semester 1", result[0].Semester.SemesterName);
            Assert.Equal("Excellent", result[1].Description);
            Assert.Equal("Semester 2", result[1].Semester.SemesterName);
        }


        [Fact]
        public async Task GetPupilFeedbacks_ShouldReturnNull_WhenNoFeedbacksExist()
        {
            // Arrange
            var pupilId = 1;

            _unitOfWorkMock.Setup(uow => uow.FeedbackRepository.GetAllFeedbacksOfPupil(pupilId))
                .ReturnsAsync(new List<PupilFeedback>());

            // Act
            var result = await _pupilFeedbackService.GetPupilFeedbacks(pupilId);

            // Assert
            Assert.Null(result);
        }

    }
}
