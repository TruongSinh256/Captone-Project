﻿using Xunit;
using Moq;
using sep.backend.v1.Services;
using sep.backend.v1.Services.UnitOfWork;
using sep.backend.v1.DTOs;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.Exceptions;
using System.Linq.Expressions;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace sep.test.v1.Services
{
    public class TimetableServiceTest
    {
        private readonly Mock<IUnitOfWork> _unitOfWorkMock;
        private readonly Mock<IAutoMapper> _mapperMock;
        private readonly TimetableService _timetableService;

        public TimetableServiceTest()
        {
            _unitOfWorkMock = new Mock<IUnitOfWork>();
            _mapperMock = new Mock<IAutoMapper>();
            _timetableService = new TimetableService(_unitOfWorkMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateTimeTableAsync_ShouldCreateTimetableSuccessfully()
        {
            // Arrange
            var timetableDTO = new TimeTableDTO { ClassId = 1, SemesterId = 1, DayOfWeek = 1, TimeSlotId = 1, SubjectId = 1 };
            var timetable = new TimeTable { ClassId = 1, SemesterId = 1, DayOfWeek = 1, TimeSlotId = 1, SubjectId = 1 };

            _mapperMock.Setup(mapper => mapper.Map<TimeTableDTO, TimeTable>(timetableDTO)).Returns(timetable);
            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().GetSingleByCondition(It.IsAny<Expression<Func<TimeTable, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync((TimeTable)null);
            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().Add(timetable)).ReturnsAsync(true);

            // Act
            var result = await _timetableService.CreateTimeTableAsync(timetableDTO);

            // Assert
            Assert.True(result);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

        [Fact]
        public async Task CreateTimeTableAsync_ShouldThrowConflictException_WhenTimetableAlreadyExists()
        {
            // Arrange
            var timetableDTO = new TimeTableDTO { ClassId = 1, SemesterId = 1, DayOfWeek = 1, TimeSlotId = 1, SubjectId = 1 };
            var existingTimetable = new TimeTable { ClassId = 1, SemesterId = 1, DayOfWeek = 1, TimeSlotId = 1, SubjectId = 1 };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().GetSingleByCondition(It.IsAny<Expression<Func<TimeTable, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(existingTimetable);

            // Act & Assert
            await Assert.ThrowsAsync<ConflictException>(() => _timetableService.CreateTimeTableAsync(timetableDTO));
        }

        [Fact]
        public async Task DeleteTimeTableAsync_ShouldDeleteTimetableSuccessfully()
        {
            // Arrange
            var timetableDTO = new TimeTableDTO { ClassId = 1, SemesterId = 1, DayOfWeek = 1, TimeSlotId = 1 };
            var timetableList = new List<TimeTable>
            {
                new TimeTable { ClassId = 1, SemesterId = 1, DayOfWeek = 1, TimeSlotId = 1 }
            };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().GetMulti(It.IsAny<Expression<Func<TimeTable, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(timetableList);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().DeleteMulti(It.IsAny<Expression<Func<TimeTable, bool>>>()));

            // Act
            var result = await _timetableService.DeleteTimeTableAsync(timetableDTO);

            // Assert
            Assert.True(result);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Once);
        }

        [Fact]
        public async Task DeleteTimeTableAsync_ShouldThrowNotFoundException_WhenNoTimetableExists()
        {
            // Arrange
            var timetableDTO = new TimeTableDTO { ClassId = 1, SemesterId = 1, DayOfWeek = 1, TimeSlotId = 1 };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().GetMulti(It.IsAny<Expression<Func<TimeTable, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(new List<TimeTable>());

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _timetableService.DeleteTimeTableAsync(timetableDTO));
        }

        [Fact]
        public async Task UpdateTimeTableAsync_ShouldUpdateTimetableSuccessfully()
        {
            // Arrange
            var timetableDTO = new TimeTableDTO
            {
                ClassId = 1,
                SemesterId = 1,
                DayOfWeek = 1,
                TimeSlotId = 1,
                SubjectId = 2
            };

            var existingTimetable = new TimeTable
            {
                ClassId = 1,
                SemesterId = 1,
                DayOfWeek = 1,
                TimeSlotId = 1,
                SubjectId = 1
            };

            var updatedTimetable = new TimeTable
            {
                ClassId = 1,
                SemesterId = 1,
                DayOfWeek = 1,
                TimeSlotId = 1,
                SubjectId = 2
            };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().GetSingleByCondition(It.IsAny<Expression<Func<TimeTable, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(existingTimetable);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().GetMulti(It.IsAny<Expression<Func<TimeTable, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(new List<TimeTable> { existingTimetable });

            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().DeleteMulti(It.IsAny<Expression<Func<TimeTable, bool>>>()));

            _mapperMock.Setup(mapper => mapper.Map<TimeTableDTO, TimeTable>(timetableDTO)).Returns(updatedTimetable);

            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().Add(It.IsAny<TimeTable>())).ReturnsAsync(true);

            // Act
            var result = await _timetableService.UpdateTimeTableAsync(timetableDTO);

            // Assert
            Assert.True(result);
            _unitOfWorkMock.Verify(uow => uow.CompleteAsync(), Times.Exactly(2)); // Called during delete and add
            _unitOfWorkMock.Verify(uow => uow.GetRepository<TimeTable>().DeleteMulti(It.IsAny<Expression<Func<TimeTable, bool>>>()), Times.Once);
            _unitOfWorkMock.Verify(uow => uow.GetRepository<TimeTable>().Add(It.IsAny<TimeTable>()), Times.Once);
        }


        [Fact]
        public async Task GetTimeTableDetailAsync_ShouldReturnDetails_WhenTimetablesExist()
        {
            // Arrange
            var classId = 1;
            var semesterId = 1;
            var timetables = new List<TimeTable>
            {
                new TimeTable { ClassId = classId, SemesterId = semesterId, DayOfWeek = 1, TimeSlotId = 1, SubjectId = 1 }
            };

            var timetableDetails = new List<TimeTableDetailDTO>
            {
                new TimeTableDetailDTO { ClassId = classId, SemesterId = semesterId, DayOfWeek = 1, TimeSlotId = 1, SubjectId = 1 }
            };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().GetMulti(It.IsAny<Expression<Func<TimeTable, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(timetables);

            _mapperMock.Setup(mapper => mapper.Map<TimeTable, TimeTableDetailDTO>(It.IsAny<TimeTable>()))
                .Returns(timetableDetails[0]);

            // Act
            var result = await _timetableService.GetTimeTableDetailAsync(classId, semesterId);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
        }
        [Fact]
        public async Task DeleteTimeTableAsync_ShouldThrowNotFoundException_WhenTimetableDoesNotExist()
        {
            // Arrange
            var timetableDTO = new TimeTableDTO
            {
                ClassId = 1,
                SemesterId = 1,
                DayOfWeek = 1,
                TimeSlotId = 1
            };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().GetMulti(It.IsAny<Expression<Func<TimeTable, bool>>>(), It.IsAny<string[]>())).ReturnsAsync(new List<TimeTable>());

            // Act & Assert
            await Assert.ThrowsAsync<NotFoundException>(() => _timetableService.DeleteTimeTableAsync(timetableDTO));
            _unitOfWorkMock.Verify(uow => uow.GetRepository<TimeTable>().DeleteMulti(It.IsAny<Expression<Func<TimeTable, bool>>>()), Times.Never);
        }

        [Fact]
        public async Task GetTimeTableDetailAsync_ShouldReturnTimetableDetails()
        {
            // Arrange
            var classId = 1;
            var semesterId = 1;

            var timetables = new List<TimeTable>
    {
        new TimeTable { ClassId = classId, SemesterId = semesterId, DayOfWeek = 1, TimeSlotId = 1, SubjectId = 2 }
    };

            var timetableDetails = new List<TimeTableDetailDTO>
    {
        new TimeTableDetailDTO { ClassId = classId, SemesterId = semesterId, DayOfWeek = 1, TimeSlotId = 1, SubjectId = 2 }
    };

            _unitOfWorkMock.Setup(uow => uow.GetRepository<TimeTable>().GetMulti(It.IsAny<Expression<Func<TimeTable, bool>>>(), It.IsAny<string[]>()))
                .ReturnsAsync(timetables);

            _mapperMock.Setup(mapper => mapper.Map<TimeTable, TimeTableDetailDTO>(It.IsAny<TimeTable>()))
                .Returns((TimeTable t) => new TimeTableDetailDTO
                {
                    ClassId = t.ClassId,
                    SemesterId = t.SemesterId,
                    DayOfWeek = t.DayOfWeek,
                    TimeSlotId = t.TimeSlotId,
                    SubjectId = t.SubjectId
                });

            // Act
            var result = await _timetableService.GetTimeTableDetailAsync(classId, semesterId);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Equal(timetableDetails[0].ClassId, result[0].ClassId);
            Assert.Equal(timetableDetails[0].SemesterId, result[0].SemesterId);
        }


    }
}
