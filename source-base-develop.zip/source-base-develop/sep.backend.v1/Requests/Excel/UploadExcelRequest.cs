﻿namespace sep.backend.v1.Requests.Excel
{
    public class UploadExcelRequest
    {
        public IFormFile? File { get; set; }

    }
}
