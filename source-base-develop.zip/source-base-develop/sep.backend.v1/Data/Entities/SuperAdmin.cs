﻿namespace sep.backend.v1.Data.Entities
{
    public class SuperAdmin: BaseUserEntity
    {
    }
}
