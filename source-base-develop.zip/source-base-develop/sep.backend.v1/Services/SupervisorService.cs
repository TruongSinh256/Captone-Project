﻿using sep.backend.v1.Services.IServices;

namespace sep.backend.v1.Services
{
    public class SupervisorService : ISupervisorService
    {
    }
}
