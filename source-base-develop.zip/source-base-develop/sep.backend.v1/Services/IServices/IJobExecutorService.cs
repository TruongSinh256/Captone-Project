﻿namespace sep.backend.v1.Services.IServices;

public interface IJobExecutorService
{
    Task ExecuteAsync();
}