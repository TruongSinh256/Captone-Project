﻿namespace sep.backend.v1.Services.IServices
{
    public interface ISupervisorService
    {
    }
}
