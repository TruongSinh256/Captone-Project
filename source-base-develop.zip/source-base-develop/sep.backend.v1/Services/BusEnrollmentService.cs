using EFCore.BulkExtensions;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using sep.backend.v1.Common.Const;
using sep.backend.v1.Common.Enums;
using sep.backend.v1.Common.Enums;
using sep.backend.v1.Common.Filters;
using sep.backend.v1.Common.Responses;
using sep.backend.v1.Data.Entities;
using sep.backend.v1.DTOs;
using sep.backend.v1.Exceptions;
using sep.backend.v1.Extensions.EF;
using sep.backend.v1.Helpers;
using sep.backend.v1.Requests.Excel;
using sep.backend.v1.Services.IServices;
using sep.backend.v1.Services.UnitOfWork;
using sep.backend.v1.Validators;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace sep.backend.v1.Services
{
    public class BusEnrollmentService : BaseService<BusEnrollmentDTO, BusEnrollment>, IBusEnrollmentService
    {
        private ApplicationContext _context;
        public BusEnrollmentService(IUnitOfWork unitOfWork, IAutoMapper mapper, ApplicationContext context) : base(unitOfWork, mapper)
        {
            _context = context;
        }

        public async Task<bool> CreateBusEnrollment(CreateBusEnrollmentDTO[] busEnrollmentDto)
        {
            await _unitOfWork.BeginTransactionAsync();
            try
            {
                var busIds = busEnrollmentDto.Select(x => x.BusId).Distinct().ToArray();
                if (busIds.Length > 1 || busIds.Length == 0)
                {
                    throw new ConflictException(Responses.ConflictBus);
                }
                var bus = await _unitOfWork.BusRepository.GetSingleByCondition(x => x.Id == busIds[0]);
                if (bus is null)
                {
                    var placeholders = new Dictionary<string, string> { { "attribute", "xe" } };
                    throw new NotFoundException(StringHelper.FormatMessage(Responses.NotFoundMessageTemplate, placeholders));
                }
                foreach (var enrollmentDto in busEnrollmentDto)
                {
                    var existingEnrollment = await _unitOfWork.BusEnrollmentRepository.GetSingleByCondition(
                        be => be.BusId == enrollmentDto.BusId &&
                              be.SemesterId == enrollmentDto.SemesterId &&
                             ((be.PupilId == enrollmentDto.PupilId && be.BusSupervisorId == null) ||
                             (be.BusSupervisorId == enrollmentDto.BusSupervisorId && be.PupilId == null))
                    );

                    if (existingEnrollment != null)
                    {
                        throw new ConflictException(Responses.ConflictAddMemberBus);
                    }
                }
                var currentEnrollmentCount = await _unitOfWork.BusEnrollmentRepository.GetMulti(be => be.BusId == bus.Id && be.SemesterId == busEnrollmentDto[0].SemesterId);
                var seatActiveInBus = currentEnrollmentCount.Count();
                var totalEnrollments = seatActiveInBus + busEnrollmentDto.Length;
                if (totalEnrollments > bus.SeatNumber)
                {
                    var availableSeats = bus.SeatNumber - seatActiveInBus;
                    var placeholders = new Dictionary<string, string> { { "actualSeat", availableSeats.ToString() } };
                    throw new NotFoundException(StringHelper.FormatMessage(Responses.ConflictAddPupilsToBus, placeholders));
                }
                await _unitOfWork.BusEnrollmentRepository.CheckEnrollmentIdsExistAsync(busEnrollmentDto);
                var newEnrollment = _mapper.Map<CreateBusEnrollmentDTO[], BusEnrollment[]>(busEnrollmentDto);

                await _context.BulkInsertAsync(newEnrollment);
                await _unitOfWork.CompleteAsync();
                await _unitOfWork.CommitTransactionAsync();

                return true;
            }
            catch (Exception)
            {
                await _unitOfWork.RollbackTransactionAsync();
                throw;
            }
        }

        public async Task<CreateBusEnrollmentDTO?> UpdateBusEnrollment(int id, CreateBusEnrollmentDTO busEnrollmentDto)
        {
            await _unitOfWork.BeginTransactionAsync();
            try
            {
                var enrollment = await _unitOfWork.BusEnrollmentRepository.GetById(id);
                if (enrollment == null)
                {
                    var placeholders = new Dictionary<string, string> { { "attribute", "thông tin" } };
                    throw new NotFoundException(StringHelper.FormatMessage(Responses.NotFoundMessageTemplate, placeholders));
                }

                _mapper.Map(busEnrollmentDto, enrollment);
                _unitOfWork.BusEnrollmentRepository.Update(enrollment);
                await _unitOfWork.CompleteAsync();
                await _unitOfWork.CommitTransactionAsync();

                return _mapper.Map<BusEnrollment, CreateBusEnrollmentDTO>(enrollment);
            }
            catch (Exception)
            {
                await _unitOfWork.RollbackTransactionAsync();
                throw;
            }
        }

        public async Task<bool> DeleteBusEnrollment(int id)
        {
            await _unitOfWork.BeginTransactionAsync();
            try
            {
                var enrollment = await _unitOfWork.BusEnrollmentRepository.GetById(id);
                if (enrollment == null)
                {
                    var placeholders = new Dictionary<string, string> { { "attribute", "thông tin" } };
                    throw new NotFoundException(StringHelper.FormatMessage(Responses.NotFoundMessageTemplate, placeholders));
                }

                _unitOfWork.BusEnrollmentRepository.Delete(enrollment.Id);
                await _unitOfWork.CompleteAsync();
                await _unitOfWork.CommitTransactionAsync();

                return true;
            }
            catch (Exception)
            {
                await _unitOfWork.RollbackTransactionAsync();
                throw;
            }
        }

        public async Task<BusEnrollmentDTO?> GetBusEnrollmentDetail(int id)
        {
            var enrollments = await _unitOfWork.BusEnrollmentRepository.GetMulti(
                x => x.Id == id,
                new string[] { "Bus", "Pupil", "BusSupervisor", "Semester" }
            );

            var enrollment = enrollments.FirstOrDefault();
            if (enrollment == null)
            {
                var placeholders = new Dictionary<string, string> { { "attribute", "thông tin" } };
                throw new NotFoundException(StringHelper.FormatMessage(Responses.NotFoundMessageTemplate, placeholders));
            }

            return _mapper.Map<BusEnrollment, BusEnrollmentDTO>(enrollment);
        }

        public async Task<PagedResponse<List<BusEnrollmentDTO>>> GetListBusEnrollments(
            PaginationFilter filters,
            IUriService uriService,
            string route,
            int busId,
            int semesterId)
        {
            var validFilter = new PaginationFilter(filters.PageNumber, filters.PageSize);
            var pagedData = await _unitOfWork.BusEnrollmentRepository.GetBusEnrollments(busId, semesterId);
            var totalRecords = pagedData.Count();
            var enrollmentDto = _mapper.Map<List<BusEnrollment>, List<BusEnrollmentDTO>>(pagedData);
            var sortedEnrollmentDto = enrollmentDto
                .OrderByDescending(x => x.BusSupervisorId != null)
                .ThenBy(x => x.PupilName)
                .ToList();

            return PagedResponseHelper.CreatePagedResponse(
                sortedEnrollmentDto.AsQueryable(),
                validFilter,
                totalRecords,
                uriService,
                route
            );
        }

        public async Task<List<PupilDetailDTO>> GetPupilWithoutEnrollments(int semesterId, int schoolId)
        {
            var enrolledPupils = await _unitOfWork.BusEnrollmentRepository.GetMulti(x => x.SemesterId == semesterId && x.PupilId != null);
            var allPupils = await _unitOfWork.PupilRepository.GetMulti(x => x.SchoolId == schoolId && (x.AccountStatus == (int)Statuses.Active || x.AccountStatus == (int)Statuses.Inactive));
            var pupilsWithoutEnrollments = allPupils.Where(p => !enrolledPupils.Any(ep => ep.PupilId == p.Id)).ToList();
            if (pupilsWithoutEnrollments.Count == 0)
            {
                var placeholders = new Dictionary<string, string>
            {
                { "attribute", "thông tin" }
            };
                throw new NotFoundException(StringHelper.FormatMessage(Responses.NotFoundMessageTemplate, placeholders));
            }
            return _mapper.Map<List<Pupil>, List<PupilDetailDTO>>(pupilsWithoutEnrollments);
        }

        public async Task<List<BusSupervisorDTO>> GetBusSupervisorWithoutEnrollments(int semesterId, int schoolId)
        {
            var enrolledSupervisors = await _unitOfWork.BusEnrollmentRepository.GetMulti(x => x.SemesterId == semesterId && x.BusSupervisorId != null);
            var allSupervisors = await _unitOfWork.BusSupervisorRepository.GetMulti(x => x.SchoolId == schoolId && (x.AccountStatus == (int)Statuses.Active || x.AccountStatus == (int)Statuses.Inactive));
            var supervisorsWithoutEnrollments = allSupervisors
                .Where(s => !enrolledSupervisors.Any(es => es.BusSupervisorId == s.Id))
                .ToList();
            if (supervisorsWithoutEnrollments.Count == 0)
            {
                var placeholders = new Dictionary<string, string>
            {
                { "attribute", "thông tin" }
            };
                throw new NotFoundException(StringHelper.FormatMessage(Responses.NotFoundMessageTemplate, placeholders));
            }
            return _mapper.Map<List<BusSupervisor>, List<BusSupervisorDTO>>(supervisorsWithoutEnrollments);
        }
        public async Task<List<PupilDetailDTO>> GetListPupilsInBusStop(int semesterId, int busStopId, int schoolId)
        {
            var enrolledPupils = await _unitOfWork.BusEnrollmentRepository.GetMulti(x => x.SemesterId == semesterId && x.BusStopId == busStopId);
            var allPupils = await _unitOfWork.PupilRepository.GetMulti(x => x.SchoolId == schoolId && (x.AccountStatus == (int)Statuses.Active || x.AccountStatus == (int)Statuses.Inactive));
            var pupilsWithoutEnrollments = allPupils.Where(p => enrolledPupils.Any(ep => ep.PupilId == p.Id)).ToList();
            if (pupilsWithoutEnrollments.Count == 0)
            {
                var placeholders = new Dictionary<string, string>
            {
                { "attribute", "thông tin" }
            };
                throw new NotFoundException(StringHelper.FormatMessage(Responses.NotFoundMessageTemplate, placeholders));
            }

            return _mapper.Map<List<Pupil>, List<PupilDetailDTO>>(pupilsWithoutEnrollments);
        }

        public async Task<(bool isSuccess, string errorFilePath)> ImportExcelToCreateMemberBusAsync(int schoolId, UploadExcelRequest uploadExcelFileRequest)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;


            var filePath = await UploadFileExcelAsync(uploadExcelFileRequest);

            var memberList = await ProcessExcelFileAsync(filePath,schoolId);

            await CreateBusEnrollment(memberList);

            return (true, null);
        }

        public async Task<List<BusEnrollmentDTO>> GetMemberToCopy(int nextSemesterId)
        {
            var enrollmentsInNextSemester = await _unitOfWork.BusEnrollmentRepository.GetMembersInNextSemester(nextSemesterId);
            if (enrollmentsInNextSemester.Count == 0)
            {
                var placeholders = new Dictionary<string, string> { { "attribute", "thông tin" } };
                throw new NotFoundException(StringHelper.FormatMessage(Responses.NotFoundMessageTemplate, placeholders));
            }

            var newEnrollment = _mapper.Map<List<BusEnrollment>, List<BusEnrollmentDTO>>((List<BusEnrollment>)enrollmentsInNextSemester);

            return newEnrollment;
        }
        private async Task<string> UploadFileExcelAsync(UploadExcelRequest uploadExcelFileRequest)
        {
            if (uploadExcelFileRequest.File != null && uploadExcelFileRequest.File.Length > 0)
            {
                var fileHelper = new FileUploadHelper();
                return await fileHelper.UploadExcelFile(uploadExcelFileRequest.File, "excel-bus-enrollment");
            }
            return null;
        }

        public async Task<CreateBusEnrollmentDTO[]> ProcessExcelFileAsync(string filePath, int schoolId)
        {
            var busEnrollmentDtos = new List<CreateBusEnrollmentDTO>();

            using (var package = new ExcelPackage(new FileInfo(filePath)))
            {
                var worksheet = package.Workbook.Worksheets[0];
                var rowCount = worksheet.Dimension.Rows;

                for (int row = 2; row <= rowCount; row++) 
                {
                    try
                    {
                        var busEnrollmentDto = await CreateBusEnrollmentDTOFromRow(worksheet, row, schoolId);
                        busEnrollmentDtos.Add(busEnrollmentDto);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Lỗi tại dòng {row}: {ex.Message}");
                    }
                }
            }
            return busEnrollmentDtos.ToArray();
        }

        private async Task<CreateBusEnrollmentDTO> CreateBusEnrollmentDTOFromRow(ExcelWorksheet worksheet, int row, int schoolId)
        {
            // Lấy dữ liệu từ từng cột trong Excel
            var userName = worksheet.Cells[row, 5].Text;         // Cột 1: Username
            var busRouteName = worksheet.Cells[row, 6].Text;     // Cột 2: Tên tuyến xe
            var busName = worksheet.Cells[row, 7].Text;          // Cột 3: Tên xe
            var busStop = worksheet.Cells[row, 8].Text;          // Cột 4: Điểm dừng
            var semester = worksheet.Cells[row, 9].Text;         // Cột 5: Kỳ học
            var schoolYear = worksheet.Cells[row, 10].Text;       // Cột 6: Năm học

            // Kiểm tra tính hợp lệ của các giá trị từ Excel
            var busRoute = await _unitOfWork.BusRouteRepository.GetSingleByCondition(x => x.Name.Equals(busRouteName) && x.SchoolId == schoolId); 
            if (busRoute == null)
            {
                throw new NotFoundException($"Không tìm thấy xe buýt với tên tuyến {busRouteName}");
            }
            var bus = await _unitOfWork.BusRepository.GetSingleByCondition(x => x.Name.Equals(busName) && x.BusRouteId == busRoute.Id);
            if (bus == null)
            {
                throw new NotFoundException($"Không tìm thấy xe buýt với tên {busName}");
            }

            var busStopEntity = await _unitOfWork.BusStopRepository.GetSingleByCondition(x => x.Name == busStop && x.BusRouteId == busRoute.Id);
            if (busStopEntity == null)
            {
                throw new NotFoundException($"Không tìm thấy điểm dừng với tên {busStop}");
            }

            var schoolYearEntity = await _unitOfWork.GetRepository<SchoolYear>().GetSingleByCondition(x => x.Name == schoolYear);
            if (schoolYearEntity == null)
            {
                throw new NotFoundException($"Không tìm thấy năm học {schoolYear}");
            }

            var semesters = await _unitOfWork.GetRepository<Semester>()
                .GetMulti(x => x.SchoolYearId == schoolYearEntity.Id);
            var sortedSemesters = semesters.OrderBy(x => x.StartDate).ToList();

            var semesterEntity = semesters.FirstOrDefault(x => x.SemesterName == semester && x.SchoolYearId == schoolYearEntity.Id);
            if (semesterEntity == null)
            {
                throw new NotFoundException($"Không tìm thấy kỳ học {semester}");
            }

            // Kiểm tra kỳ học đang hoạt động
            var currentSemester = semesters.FirstOrDefault(x => x.IsActive);
            if (currentSemester == null)
            {
                throw new NotFoundException("Hiện tại không có kỳ học nào hoạt động!");
            }

            // Kiểm tra kỳ học tiếp theo
            var nextSemester = semesters.FirstOrDefault(x => x.StartDate > DateTime.Now);

            if (semesterEntity.Id != currentSemester.Id && (nextSemester == null || semesterEntity.Id != nextSemester.Id))
            {
                throw new NotFoundException("Chỉ thêm được ở kỳ hiện tại và tiếp theo!");
            }

            var pupils = await _unitOfWork.GetRepository<Pupil>().GetSingleByCondition(x => x.Username == userName && x.SchoolId == schoolId);
            if (semesterEntity == null)
            {
                throw new NotFoundException($"Không tìm thấy học sinh {semester}");
            }

            // Tạo DTO
            return new CreateBusEnrollmentDTO
            {
                PupilId = pupils.Id,
                BusId = bus.Id,
                BusSupervisorId = null,
                SemesterId = semesterEntity.Id,
                BusStopId = busStopEntity.Id
            };

        }
        public async Task<(byte[] fileBytes, string contentType, string fileName)> DownloadBusErrolTemplateAsync()
        {
            string subFolder = "Templates/Excel";
            string fileName = "template_listbus.xlsx";

            var fileHelper = new FileDownloadHelper();
            var fileBytes = fileHelper.GetFileBytes(subFolder, fileName);
            string contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

            return (fileBytes, contentType, fileName);

        }
    }
}
