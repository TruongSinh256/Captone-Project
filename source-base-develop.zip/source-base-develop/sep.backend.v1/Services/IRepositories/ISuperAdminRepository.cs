﻿namespace sep.backend.v1.Services.IRepositories
{
    public interface ISuperAdminRepository
    {
    }
}
