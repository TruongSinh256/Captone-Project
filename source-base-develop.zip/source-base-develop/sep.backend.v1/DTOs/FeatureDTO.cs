﻿namespace sep.backend.v1.DTOs
{
    public class FeatureDTO
    {
        public int Id { get; set; }
        public string FeatureName { get; set; }
        public string? Description { get; set; }
    }
}
