﻿namespace sep.backend.v1.DTOs;

public class EmailScheduleDTO
{
    public int SchoolId { get; set; }
    public string Email { get; set; }
}