﻿namespace sep.backend.v1.Common.Const
{
    internal static class DefaultPassword
    {
        public const string TEACHER_PASSWORD = "1234567@Teacher";
        public const string DONOR_PASSWORD = "1234567@Donor";
        public const string BUS_SUPERVISOR_PASSWORD = "1234567@Bus";
    }
}
