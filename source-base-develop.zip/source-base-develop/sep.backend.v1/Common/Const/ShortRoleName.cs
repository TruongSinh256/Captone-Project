﻿namespace sep.backend.v1.Common.Const
{
    internal static class ShortRoleName
    {
        public const string SUPER_ADMIN = "SPA";
        public const string SCHOOL_ADMIN = "SA";
        public const string BUS_SUPER_VISOR = "BSV";
        public const string DONNOR = "DN";
        public const string TEACHER = "TC";
    }
}
