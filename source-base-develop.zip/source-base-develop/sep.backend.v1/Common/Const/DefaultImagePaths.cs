﻿namespace sep.backend.v1.Common.Const
{
    public static class DefaultImagePaths
    {
        public static readonly string DefaultAvatar = Path.Combine("Resources", "Images", "default-avatar.png").Replace("\\", "/");
    }
}
