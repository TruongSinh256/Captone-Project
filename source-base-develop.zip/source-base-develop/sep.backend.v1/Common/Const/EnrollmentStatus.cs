﻿namespace sep.backend.v1.Common.Const
{
    public static class EnrollmentStatus
    {
        public const int HOMEROOM_ASSIGNED = 0;
        public const int HOMEROOM_UNASSIGNED = 1;
        public const int ENROLLED = 2;
        public const int FINISH = 3;
    }
}
