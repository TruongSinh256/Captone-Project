﻿namespace sep.backend.v1.Common.Enums
{
    public enum Subscription
    {
        Trial = 1,
        Normal = 2,
        Vip = 3,
    }
}