﻿namespace sep.backend.v1.Common.Enums
{
    public enum ModeLogin
    {
        SuperAdmin = 0,
        SchoolAdmin = 1,
        Donnor = 2,
        Teacher = 3,
        BusSuperVisor = 4,
    }
}
    