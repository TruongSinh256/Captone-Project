﻿namespace sep.backend.v1.Helpers
{
    public class FileDownloadHelper
    {
        private readonly string _baseFolder;

        public FileDownloadHelper()
        {
            _baseFolder = Path.Combine(Directory.GetCurrentDirectory(), "Resources");
        }

        public byte[] GetFileBytes(string subFolder, string fileName)
        {
            var filePath = Path.Combine(_baseFolder, subFolder, fileName);

            if (!File.Exists(filePath))
                throw new FileNotFoundException("File không tồn tại.", filePath);

            return File.ReadAllBytes(filePath);
        }

        public string GetFilePath(string subFolder, string fileName)
        {
            var filePath = Path.Combine(_baseFolder, subFolder, fileName);

            if (!File.Exists(filePath))
                throw new FileNotFoundException("File không tồn tại.", filePath);

            return filePath;
        }
    }
}
